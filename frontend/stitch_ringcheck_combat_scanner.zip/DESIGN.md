---
name: RingCheck
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c4c9ac'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8e9379'
  outline-variant: '#444933'
  surface-tint: '#abd600'
  primary: '#ffffff'
  on-primary: '#283500'
  primary-container: '#c3f400'
  on-primary-container: '#556d00'
  inverse-primary: '#506600'
  secondary: '#ffdb9d'
  on-secondary: '#412d00'
  secondary-container: '#feb700'
  on-secondary-container: '#6b4b00'
  tertiary: '#ffffff'
  on-tertiary: '#00363a'
  tertiary-container: '#7df4ff'
  on-tertiary-container: '#006f77'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c3f400'
  primary-fixed-dim: '#abd600'
  on-primary-fixed: '#161e00'
  on-primary-fixed-variant: '#3c4d00'
  secondary-fixed: '#ffdea8'
  secondary-fixed-dim: '#ffba20'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#5e4200'
  tertiary-fixed: '#7df4ff'
  tertiary-fixed-dim: '#00dbe9'
  on-tertiary-fixed: '#002022'
  on-tertiary-fixed-variant: '#004f54'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Anton
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: 0.02em
  headline-lg:
    fontFamily: Anton
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: 0.02em
  headline-lg-mobile:
    fontFamily: Anton
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 32px
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
  data-num:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 40px
---

## Brand & Style

This design system is engineered for elite performance and tactical precision. The brand personality is **energetic, confident, and authoritative**, moving away from clinical aesthetics toward a high-octane, gear-oriented experience. It targets athletes and tech-enthusiasts who demand professional-grade tools.

The design style is a hybrid of **High-Contrast Bold** and **Tactical Modernism**. It mimics the interface of high-end optical equipment and performance tracking hardware. Visuals are characterized by sharp geometry, precise data visualization, and "active" UI states that utilize subtle glows to simulate illuminated hardware displays. The interface should feel like a heads-up display (HUD) for physical performance.

## Colors

The palette is anchored in a "Black-Ops" aesthetic to maximize contrast and reduce eye strain during high-intensity use.

- **Primary (Scan-Lock Green):** A high-visibility neon used for critical "active" states, primary actions, and successful scans. It should emit a soft glow effect when used on interactive elements.
- **Secondary (Warning Amber):** Reserved for cautionary data, secondary alerts, and high-priority physiological indicators.
- **Tertiary (Data Cyan):** Used sparingly for auxiliary technical data and secondary navigational elements.
- **Neutral (Onyx/Charcoal):** A tiered system of deep greys creates the structural skeleton. Backgrounds use the deepest black to make the neon accents "pop" with maximum luminance.

## Typography

The typography system prioritizes immediate legibility and a "technical readout" feel.

- **Headlines:** Uses **Anton** for a high-impact, condensed geometric look. All major headlines must be uppercase to convey confidence and urgency.
- **Body:** Uses **Geist** for its clean, developer-centric precision. It provides a highly readable contrast to the aggressive headlines.
- **Labels & Metadata:** Uses **Space Mono** to reinforce the tactical, machine-interface aesthetic. This is used for timestamps, unit measurements (e.g., BPM, KM/H), and technical captions.

## Layout & Spacing

The layout philosophy follows a **strict modular grid** that feels engineered rather than organic.

- **Grid:** A 12-column fluid grid for tablet/desktop and a 4-column grid for mobile.
- **Rhythm:** An 8px base unit is used for most spacing, but 4px "micro-steps" are allowed for tight technical data layouts.
- **Structure:** Content should be contained within defined "cells" or "modules" with clear, visible borders. Avoid loose, floating elements; every component should feel "docked" into the interface.
- **Margins:** Use generous 20px side margins on mobile to ensure the interface feels framed and focused.

## Elevation & Depth

This system avoids traditional soft shadows in favor of **Tonal Layering** and **Luminous Depth**.

- **Surface Levels:** Depth is created by lightening the background hex slightly (from #0A0A0A to #1A1A1B) as elements "rise" toward the user.
- **Tactile Borders:** Instead of shadows, use 1px solid borders in `border_tactical` or low-opacity versions of the primary color to define edges.
- **Glows:** Primary buttons and active status indicators use a `0px 0px 12px` outer glow matching their accent color (Scan-Lock Green) to simulate an illuminated hardware display.
- **Optical Overlays:** Use subtle 10% opacity scan-line patterns or grid overlays on large image backgrounds to maintain the "viewfinder" aesthetic.

## Shapes

The shape language is **aggressive and precise**.

- **Corners:** Use **Soft (0.25rem)** as the maximum roundedness for standard components. Higher roundedness levels are prohibited to maintain the tactical gear aesthetic. 
- **Corner Treatments:** For specific "Hero" modules, use a "clipped corner" (45-degree chamfer) look to mimic ruggedized military tech.
- **Buttons:** Rectangular with minimal 4px radius. Action icons should be framed in square containers.

## Components

- **Tactical Buttons:** Primary buttons are solid Scan-Lock Green with black text. Secondary buttons are ghost-style with a 1px tactical border and primary color text.
- **Data Chips:** Small, rectangular tags with Space Mono text. Use primary/secondary colors for the background at 15% opacity with a 100% opacity border.
- **Status Indicators:** "Active" states should pulse slightly with a green glow. "Warning" states use a static Amber border.
- **Input Fields:** Bottom-border only or full-outline with 1px width. Focus state triggers a subtle green outer glow and shifts the label to the Primary color.
- **Cards/Modules:** Use a slightly lighter Onyx surface than the background. Headers within cards should have a 1px bottom separator to divide the "Title" from the "Data."
- **Progress Bars:** Segmented blocks (e.g., 10 distinct rectangles) rather than a smooth continuous fill to look like a hardware battery or signal indicator.
- **Viewfinder Overlays:** Corner "L" brackets should be used on camera-based or scanning screens to frame the content.